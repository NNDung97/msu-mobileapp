import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../model/login_result.dart';

class AuthStorage {
  static const _storage = FlutterSecureStorage();

  static Future<void> saveLogin(LoginResult result) async {
    await _storage.write(key: "access_token", value: result.accessToken);
    await _storage.write(key: "refresh_token", value: result.refreshToken);
    await _storage.write(key: "wallet_address", value: result.walletAddress);
    await _storage.write(key: "user_id", value: result.userId);
  }

  static Future<String?> getAccessToken() =>
      _storage.read(key: "access_token");

  static Future<void> clear() async {
    await _storage.deleteAll();
  }
}
